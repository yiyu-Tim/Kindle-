KJSF-KTE1:RED
很多人苦恼很好用的kindle text editor(KTE)没有kual菜单
每次打开都要输入在搜索栏里输入;log runme
于是我做了一个插件用来在kual启动KTE
原理是runme.sh文件有一个固定的open文件索引(/mnt/us/extensions/n31_kte/n31_kte)
不会因为移动shell文件位置就打不开插件

KJSF-KTE2:RED
我手写了xml和josn用于打开(KTErun\bin\KTErun.sh)

END-
如有侵权联系删除：eeyu9543@gmail.com
发布:OpenYU